﻿namespace WeatherForecast.CommonData.RabbitQueue
{
    public class Queue
    {
        public static string Processing { get; } = "StartProcessingQueue";
    }
}
